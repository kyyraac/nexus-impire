# Nexus Control — Nexus Family

Bot Discord Node.js untuk:
- Welcome message dengan GIF (GIF tampil sebagai media embed; tidak menggabungkan avatar ke dalam GIF)
- Moderasi: `/kick`, `/ban`, `/timeout`, `/untimeout`
- Ticket: `/ticket-setup`, tombol Open Ticket dan Close Ticket
- Invite tracker: `/invites`
- Auto role: `/autorole`
- Embed builder: `/embed`
- Setelan welcome: `/welcome-setup`
- Log channel: `/setlog`

## Penting sebelum deploy
1. Buat aplikasi di https://discord.com/developers/applications
2. Di **Bot**, buat bot dan salin token secara pribadi.
3. Di **OAuth2 > URL Generator**, pilih scopes `bot` dan `applications.commands`.
4. Pilih bot permissions: `View Channels`, `Send Messages`, `Embed Links`, `Attach Files`, `Read Message History`, `Manage Channels`, `Manage Roles`, `Kick Members`, `Ban Members`, `Moderate Members`, `Manage Guild`.
5. Undang bot ke server Nexus Family.
6. Aktifkan **Server Members Intent** dan **Presence Intent tidak diperlukan** di Developer Portal > Bot. Invite tracking membutuhkan akses Manage Server pada bot. Pastikan juga bot punya izin Manage Server bila Discord memerlukannya untuk membaca invites.
7. Pastikan role bot ditempatkan di atas role yang ingin dikelola.

## Deploy dari HP Android dengan Render + GitHub
1. Buat repository GitHub baru bernama `nexus-control`.
2. Upload semua file dan folder dari ZIP ini ke repository. Jangan upload `.env` asli atau token.
3. Buka https://render.com lalu login dan hubungkan GitHub.
4. Pilih **New + > Web Service**, lalu pilih repository `nexus-control`.
5. Isi:
   - Build Command: `npm install`
   - Start Command: `npm start`
   - Health Check Path: `/`
   - Plan: Free untuk uji coba
6. Pada **Environment**, tambah:
   - `DISCORD_TOKEN` = token bot
   - `CLIENT_ID` = Application ID dari Developer Portal
   - `GUILD_ID` = Server ID Nexus Family
7. Tekan deploy. Cek Logs, cari `Logged in as ...` dan `Registered ... commands`.

Render free web services dapat tidur setelah 15 menit tanpa trafik dan filesystem-nya sementara. Bot mungkin offline ketika service tidur; ini bukan hosting 24/7 yang dijamin. Invite counter di versi awal ini juga memakai cache memori, sehingga bisa reset saat restart/redeploy.

## Cara mengambil ID di Discord Android
Discord > Settings > Advanced > aktifkan Developer Mode. Lalu buka server/akun/role/channel yang dibutuhkan, tekan menu tiga titik dan pilih **Copy ID**.

## Perintah
- `/welcome-setup channel gif_url message` — set channel welcome, URL GIF, dan pesan. Pakai URL gambar langsung berakhiran `.gif` atau URL CDN yang memang menampilkan GIF.
- `/autorole role` — role otomatis member baru.
- `/ticket-setup channel` — kirim panel tombol ticket ke channel.
- `/embed channel title description color` — kirim embed. Warna contoh: `#8b0000`.
- `/setlog channel` — channel untuk log moderasi.
- `/kick user reason`
- `/ban user reason`
- `/timeout user minutes reason`
- `/untimeout user`
- `/invites [user]` — jumlah invite yang tercatat sejak bot online.

## Ticket staff (opsional)
Jika ingin role staff bisa melihat ticket, tambahkan `STAFF_ROLE_ID` di Render Environment dengan ID role staff. Role bot tetap harus punya `Manage Channels`. `TICKET_CATEGORY_ID` dapat diisi dengan ID kategori ticket.

## Catatan
- Welcome GIF: bot mengirim teks dan GIF sebagai embed/media. Ini bukan generator GIF yang menempelkan avatar member di atas background.
- Invite tracking bergantung pada izin membaca invites dan event join. Penghitung sederhana ini tidak permanen dan bisa tidak akurat jika invite dibuat/dihapus bersamaan atau bot offline.
- Jangan pernah mengirim token bot ke orang lain atau menaruh token di file yang di-upload ke GitHub.
