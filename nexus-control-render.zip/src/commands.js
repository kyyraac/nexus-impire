import {
  SlashCommandBuilder,
  ChannelType,
  PermissionFlagsBits
} from 'discord.js';

const staffOnly = PermissionFlagsBits.ManageGuild;

export const commands = [
  new SlashCommandBuilder()
    .setName('welcome-setup')
    .setDescription('Atur welcome message dan GIF Nexus Family')
    .setDefaultMemberPermissions(staffOnly)
    .addChannelOption(o => o.setName('channel').setDescription('Channel welcome').addChannelTypes(ChannelType.GuildText).setRequired(true))
    .addStringOption(o => o.setName('gif_url').setDescription('URL langsung GIF (opsional)').setRequired(false))
    .addStringOption(o => o.setName('message').setDescription('Pesan; gunakan {user} untuk mention member').setRequired(false)),
  new SlashCommandBuilder()
    .setName('autorole')
    .setDescription('Atur role otomatis untuk member baru')
    .setDefaultMemberPermissions(staffOnly)
    .addRoleOption(o => o.setName('role').setDescription('Role yang diberikan otomatis').setRequired(true)),
  new SlashCommandBuilder()
    .setName('ticket-setup')
    .setDescription('Kirim panel tombol ticket')
    .setDefaultMemberPermissions(staffOnly)
    .addChannelOption(o => o.setName('channel').setDescription('Channel panel ticket').addChannelTypes(ChannelType.GuildText).setRequired(true)),
  new SlashCommandBuilder()
    .setName('embed')
    .setDescription('Buat dan kirim embed custom')
    .setDefaultMemberPermissions(staffOnly)
    .addChannelOption(o => o.setName('channel').setDescription('Channel tujuan').addChannelTypes(ChannelType.GuildText).setRequired(true))
    .addStringOption(o => o.setName('title').setDescription('Judul embed').setRequired(true).setMaxLength(256))
    .addStringOption(o => o.setName('description').setDescription('Isi embed').setRequired(true).setMaxLength(4000))
    .addStringOption(o => o.setName('color').setDescription('Warna hex, contoh #8b0000').setRequired(false)),
  new SlashCommandBuilder()
    .setName('setlog')
    .setDescription('Atur channel log moderasi')
    .setDefaultMemberPermissions(staffOnly)
    .addChannelOption(o => o.setName('channel').setDescription('Channel log').addChannelTypes(ChannelType.GuildText).setRequired(true)),
  new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Keluarkan member dari server')
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .addUserOption(o => o.setName('user').setDescription('Member yang dikeluarkan').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Alasan').setRequired(false).setMaxLength(400)),
  new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban member dari server')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption(o => o.setName('user').setDescription('Member yang diban').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Alasan').setRequired(false).setMaxLength(400)),
  new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Timeout member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('Member yang di-timeout').setRequired(true))
    .addIntegerOption(o => o.setName('minutes').setDescription('Durasi dalam menit (1 sampai 40320)').setRequired(true).setMinValue(1).setMaxValue(40320))
    .addStringOption(o => o.setName('reason').setDescription('Alasan').setRequired(false).setMaxLength(400)),
  new SlashCommandBuilder()
    .setName('untimeout')
    .setDescription('Hapus timeout member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('Member').setRequired(true)),
  new SlashCommandBuilder()
    .setName('invites')
    .setDescription('Lihat jumlah invite yang tercatat')
    .addUserOption(o => o.setName('user').setDescription('Member yang ingin dicek').setRequired(false))
].map(c => c.toJSON());
