import 'dotenv/config';
import express from 'express';
import {
  Client,
  GatewayIntentBits,
  Partials,
  REST,
  Routes,
  Events,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  PermissionFlagsBits
} from 'discord.js';
import { commands } from './commands.js';

const required = ['DISCORD_TOKEN', 'CLIENT_ID', 'GUILD_ID'];
for (const key of required) {
  if (!process.env[key]) {
    console.error(`Missing environment variable: ${key}`);
    process.exit(1);
  }
}

const app = express();
app.get('/', (_req, res) => res.status(200).send('Nexus Control is running.'));
app.get('/health', (_req, res) => res.status(200).json({ ok: true, bot: 'Nexus Control' }));
const port = Number(process.env.PORT || 10000);
app.listen(port, '0.0.0.0', () => console.log(`Health server listening on ${port}`));

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildInvites
  ],
  partials: [Partials.GuildMember]
});

const settings = new Map(); // In-memory configuration; reconfigure after restarts if needed.
const inviteCounts = new Map();
const inviteSnapshots = new Map();

const keyFor = (guildId, name) => `${guildId}:${name}`;

async function fetchInviteSnapshot(guild) {
  try {
    const invites = await guild.invites.fetch();
    const snapshot = new Map();
    for (const invite of invites.values()) snapshot.set(invite.code, invite.uses ?? 0);
    inviteSnapshots.set(guild.id, snapshot);
  } catch (err) {
    console.warn(`Cannot fetch invites for ${guild.name}. Check Manage Server permission.`, err.message);
  }
}

async function sendLog(guild, message) {
  const channelId = settings.get(keyFor(guild.id, 'logChannel')) || process.env.LOG_CHANNEL_ID;
  if (!channelId) return;
  const channel = guild.channels.cache.get(channelId);
  if (channel?.isTextBased()) {
    try { await channel.send({ embeds: [new EmbedBuilder().setColor(0x8b0000).setDescription(message).setTimestamp()] }); }
    catch (e) { console.warn('Could not send log:', e.message); }
  }
}

client.once(Events.ClientReady, async readyClient => {
  console.log(`Logged in as ${readyClient.user.tag}`);
  const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
  try {
    await rest.put(Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID), { body: commands });
    console.log(`Registered ${commands.length} commands for guild ${process.env.GUILD_ID}`);
  } catch (error) {
    console.error('Command registration failed:', error);
  }
  for (const guild of readyClient.guilds.cache.values()) await fetchInviteSnapshot(guild);
});

client.on(Events.InviteCreate, async invite => {
  const old = inviteSnapshots.get(invite.guild.id) || new Map();
  old.set(invite.code, invite.uses ?? 0);
  inviteSnapshots.set(invite.guild.id, old);
});
client.on(Events.InviteDelete, async invite => {
  const old = inviteSnapshots.get(invite.guild.id);
  if (old) old.delete(invite.code);
});

client.on(Events.GuildMemberAdd, async member => {
  const guild = member.guild;
  // Invite cache comparison is best-effort and can be ambiguous if multiple invites change at once.
  let usedInvite = null;
  try {
    const before = inviteSnapshots.get(guild.id) || new Map();
    const afterInvites = await guild.invites.fetch();
    for (const invite of afterInvites.values()) {
      const priorUses = before.get(invite.code) ?? 0;
      if ((invite.uses ?? 0) > priorUses) { usedInvite = invite; break; }
    }
    const next = new Map();
    for (const invite of afterInvites.values()) next.set(invite.code, invite.uses ?? 0);
    inviteSnapshots.set(guild.id, next);
  } catch (e) {
    console.warn('Invite tracking unavailable:', e.message);
  }

  if (usedInvite?.inviter?.id) {
    const countKey = keyFor(guild.id, usedInvite.inviter.id);
    inviteCounts.set(countKey, (inviteCounts.get(countKey) || 0) + 1);
  }

  const roleId = settings.get(keyFor(guild.id, 'autoRole')) || process.env.AUTO_ROLE_ID;
  if (roleId) {
    try {
      const role = await guild.roles.fetch(roleId);
      if (role && role.position < guild.members.me.roles.highest.position) await member.roles.add(role, 'Nexus Control auto role');
    } catch (e) { console.warn('Auto role failed:', e.message); }
  }

  const channelId = settings.get(keyFor(guild.id, 'welcomeChannel')) || process.env.WELCOME_CHANNEL_ID;
  const gifUrl = settings.get(keyFor(guild.id, 'welcomeGif')) || process.env.WELCOME_GIF_URL;
  const message = settings.get(keyFor(guild.id, 'welcomeMessage')) || process.env.WELCOME_MESSAGE || 'Welcome to Nexus Family, {user}!';
  const channel = channelId ? await guild.channels.fetch(channelId).catch(() => null) : null;
  if (channel?.isTextBased()) {
    const embed = new EmbedBuilder()
      .setColor(0x8b0000)
      .setTitle('影 ・ WELCOME TO NEXUS FAMILY')
      .setDescription(message.replaceAll('{user}', `<@${member.id}>`))
      .setThumbnail(member.user.displayAvatarURL({ size: 256 }))
      .setFooter({ text: 'Nexus Family • ようこそ' })
      .setTimestamp();
    if (gifUrl && /^https?:\/\//i.test(gifUrl)) embed.setImage(gifUrl);
    await channel.send({ content: `<@${member.id}>`, embeds: [embed] }).catch(e => console.warn('Welcome send failed:', e.message));
  }
});

client.on(Events.InteractionCreate, async interaction => {
  try {
    if (interaction.isChatInputCommand()) {
      const { commandName, guild, member, user } = interaction;
      if (!guild) return interaction.reply({ content: 'Gunakan perintah ini di server.', ephemeral: true });

      if (commandName === 'welcome-setup') {
        const channel = interaction.options.getChannel('channel', true);
        const gif = interaction.options.getString('gif_url') || '';
        const message = interaction.options.getString('message') || 'Welcome to Nexus Family, {user}!';
        settings.set(keyFor(guild.id, 'welcomeChannel'), channel.id);
        settings.set(keyFor(guild.id, 'welcomeGif'), gif);
        settings.set(keyFor(guild.id, 'welcomeMessage'), message);
        return interaction.reply({ content: `Welcome disetel ke ${channel}. GIF: ${gif ? 'URL tersimpan' : 'tidak dipakai'}. Catatan: setelan tersimpan di memori dan perlu diatur ulang setelah restart.`, ephemeral: true });
      }

      if (commandName === 'autorole') {
        const role = interaction.options.getRole('role', true);
        if (role.managed || role.position >= guild.members.me.roles.highest.position) {
          return interaction.reply({ content: 'Role itu tidak bisa dikelola bot. Pindahkan role bot ke atas role target, lalu coba lagi.', ephemeral: true });
        }
        settings.set(keyFor(guild.id, 'autoRole'), role.id);
        return interaction.reply({ content: `Auto role aktif: ${role}. Setelan ini perlu diatur ulang setelah restart.`, ephemeral: true });
      }

      if (commandName === 'ticket-setup') {
        const channel = interaction.options.getChannel('channel', true);
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('nexus:ticket-open').setLabel('Open Ticket').setStyle(ButtonStyle.Danger).setEmoji('🎫')
        );
        const embed = new EmbedBuilder().setColor(0x8b0000).setTitle('NEXUS FAMILY ・ SUPPORT').setDescription('Butuh bantuan? Tekan tombol di bawah untuk membuat ticket pribadi.');
        await channel.send({ embeds: [embed], components: [row] });
        return interaction.reply({ content: `Panel ticket dikirim ke ${channel}.`, ephemeral: true });
      }

      if (commandName === 'embed') {
        const channel = interaction.options.getChannel('channel', true);
        const title = interaction.options.getString('title', true);
        const description = interaction.options.getString('description', true);
        const rawColor = interaction.options.getString('color') || '#8b0000';
        const hex = rawColor.replace('#', '');
        const color = /^[0-9a-fA-F]{6}$/.test(hex) ? parseInt(hex, 16) : 0x8b0000;
        const embed = new EmbedBuilder().setColor(color).setTitle(title).setDescription(description).setFooter({ text: 'Nexus Family' }).setTimestamp();
        await channel.send({ embeds: [embed] });
        return interaction.reply({ content: `Embed berhasil dikirim ke ${channel}.`, ephemeral: true });
      }

      if (commandName === 'setlog') {
        const channel = interaction.options.getChannel('channel', true);
        settings.set(keyFor(guild.id, 'logChannel'), channel.id);
        return interaction.reply({ content: `Log moderasi diarahkan ke ${channel}. Setelan ini perlu diatur ulang setelah restart.`, ephemeral: true });
      }

      if (commandName === 'invites') {
        const target = interaction.options.getUser('user') || user;
        const count = inviteCounts.get(keyFor(guild.id, target.id)) || 0;
        return interaction.reply({ content: `**Invite tercatat untuk ${target.tag}:** ${count}\nPenghitung hanya menghitung join yang berhasil dideteksi sejak bot online dan bisa reset saat restart.`, ephemeral: true });
      }

      if (['kick', 'ban', 'timeout', 'untimeout'].includes(commandName)) {
        const target = interaction.options.getUser('user', true);
        const reason = interaction.options.getString('reason') || `Action by ${user.tag}`;
        if (target.id === user.id) return interaction.reply({ content: 'Kamu tidak bisa memakai perintah ini ke diri sendiri.', ephemeral: true });
        if (target.id === client.user.id) return interaction.reply({ content: 'Aku tidak bisa menerapkan tindakan itu ke diriku sendiri.', ephemeral: true });
        const targetMember = await guild.members.fetch(target.id).catch(() => null);
        if (!targetMember) return interaction.reply({ content: 'Member itu tidak ditemukan di server.', ephemeral: true });
        if (targetMember.id === guild.ownerId) return interaction.reply({ content: 'Tidak bisa memoderasi pemilik server.', ephemeral: true });
        const moderatorMember = await guild.members.fetch(user.id).catch(() => null);
        if (!moderatorMember) return interaction.reply({ content: 'Data moderator tidak ditemukan.', ephemeral: true });
        if (moderatorMember.roles.highest.position <= targetMember.roles.highest.position && guild.ownerId !== user.id) {
          return interaction.reply({ content: 'Role tertinggi kamu harus di atas role target.', ephemeral: true });
        }
        if (commandName === 'kick') {
          await targetMember.kick(reason);
          await sendLog(guild, `👢 **Kick:** ${target.tag}\n**Moderator:** ${user.tag}\n**Alasan:** ${reason}`);
        } else if (commandName === 'ban') {
          await guild.members.ban(target.id, { reason });
          await sendLog(guild, `🔨 **Ban:** ${target.tag}\n**Moderator:** ${user.tag}\n**Alasan:** ${reason}`);
        } else if (commandName === 'timeout') {
          const minutes = interaction.options.getInteger('minutes', true);
          await targetMember.timeout(minutes * 60 * 1000, reason);
          await sendLog(guild, `⏳ **Timeout:** ${target.tag} (${minutes} menit)\n**Moderator:** ${user.tag}\n**Alasan:** ${reason}`);
        } else {
          await targetMember.timeout(null, `Timeout removed by ${user.tag}`);
          await sendLog(guild, `✅ **Untimeout:** ${target.tag}\n**Moderator:** ${user.tag}`);
        }
        return interaction.reply({ content: `Berhasil menjalankan ${commandName} untuk ${target.tag}.`, ephemeral: true });
      }
    }

    if (interaction.isButton() && interaction.customId === 'nexus:ticket-open') {
      const guild = interaction.guild;
      const existing = guild.channels.cache.find(c => c.type === ChannelType.GuildText && c.topic === `nexus-ticket:${interaction.user.id}`);
      if (existing) return interaction.reply({ content: `Ticket kamu masih terbuka: ${existing}`, ephemeral: true });
      const categoryId = settings.get(keyFor(guild.id, 'ticketCategory')) || process.env.TICKET_CATEGORY_ID;
      const overwrites = [
        { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
        { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles] },
        { id: client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ReadMessageHistory] }
      ];
      const staffRoleId = process.env.STAFF_ROLE_ID;
      if (staffRoleId && guild.roles.cache.has(staffRoleId)) {
        overwrites.push({ id: staffRoleId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] });
      }
      const channel = await guild.channels.create({
        name: `ticket-${interaction.user.username}`.toLowerCase().replace(/[^a-z0-9-]/g, '').slice(0, 90),
        type: ChannelType.GuildText,
        topic: `nexus-ticket:${interaction.user.id}`,
        parent: categoryId || undefined,
        permissionOverwrites: overwrites,
        reason: `Ticket opened by ${interaction.user.tag}`
      });
      const closeRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('nexus:ticket-close').setLabel('Close Ticket').setStyle(ButtonStyle.Secondary)
      );
      await channel.send({ content: `<@${interaction.user.id}>`, embeds: [new EmbedBuilder().setColor(0x8b0000).setTitle('Ticket Dibuka').setDescription('Jelaskan kebutuhan kamu dengan sopan. Staff akan membantu saat tersedia.')], components: [closeRow] });
      return interaction.reply({ content: `Ticket dibuat: ${channel}`, ephemeral: true });
    }

    if (interaction.isButton() && interaction.customId === 'nexus:ticket-close') {
      const channel = interaction.channel;
      if (!channel?.topic?.startsWith('nexus-ticket:')) return interaction.reply({ content: 'Ini bukan ticket Nexus.', ephemeral: true });
      const ownerId = channel.topic.slice('nexus-ticket:'.length);
      const isOwner = interaction.user.id === ownerId;
      const isStaff = interaction.memberPermissions?.has(PermissionFlagsBits.ManageChannels);
      if (!isOwner && !isStaff) return interaction.reply({ content: 'Hanya pembuat ticket atau staff yang punya Manage Channels yang bisa menutup ticket.', ephemeral: true });
      await interaction.reply({ content: 'Ticket akan ditutup dalam 5 detik.' });
      setTimeout(() => channel.delete('Ticket closed').catch(() => {}), 5000);
    }
  } catch (error) {
    console.error('Interaction error:', error);
    const msg = 'Ada error saat menjalankan perintah. Periksa izin bot dan Render Logs.';
    if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
      await interaction.reply({ content: msg, ephemeral: true }).catch(() => {});
    } else if (interaction.isRepliable() && interaction.deferred) {
      await interaction.editReply({ content: msg }).catch(() => {});
    }
  }
});

client.on(Events.GuildMemberRemove, async member => {
  await sendLog(member.guild, `↩️ **Member keluar:** ${member.user.tag}`);
});

client.login(process.env.DISCORD_TOKEN);
